#!/usr/bin/env bash

set -o errexit
set -o pipefail
set -o nounset
# set -o xtrace

declare -a __repo_list
declare -a __error_list

__dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
__root="$(cd "$(dirname "${__dir}")" && pwd)" # <-- change this as it depends on your app

__repos_tmp_dir="/tmp/git-repos"
__jenkinsfile_path="${__root}/pipeline/multibranch/libs/Jenkinsfile"
__gitattributes_path="${__root}/.gitattributes"

__repo_list=(
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldplib/framework-boot.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldplib/framework-config.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldplib/framework-core.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldplib/framework-infra.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldplib/framework-integration.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldplib/framework-monitoring.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldplib/framework-security-mock.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldplib/framework-security-spring.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldplib/framework-security.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldplib/framework-test.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldplib/pims-commons-exception.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldplib/pims-domain-mock.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldplib/pims-persistence-commons.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldplib/pims-service-parent.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldpll/framework-core-metadata.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldpll/framework-grammar-evaluator.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldpll/framework-gwt.git"
  "https://latam.digital.alm.br.xcd.net.intra/git/scm/ldpll/framework-processors.git"
)

###############################################################################
# FUNCTIONS
###############################################################################
function _check_errors() {
  # List all repositories that have errors
  if [ ${#__error_list[@]} -gt 0 ]; then
      echo "Errors on cloning, pulling or updating:"
      for __error in "${__error_list[@]}"; do
        echo " - ${__error}"
      done
      exit 1
  fi
}


###############################################################################
# Script beginning
###############################################################################

# Removing previous repositories
rm -rf ${__repos_tmp_dir}
mkdir -p ${__repos_tmp_dir}
__error_list=()

for __repo_url in "${__repo_list[@]}"; do
  __repo_name="${__repo_url##*/}"
  __repo_name="${__repo_name%.git}"
  __repo_full_tmp_dir="${__repos_tmp_dir}/${__repo_name}"
  __error_flag=0

  echo
  echo "--------------------------------------------------------------------------------"
  echo "${__repo_name}"
  echo "--------------------------------------------------------------------------------"

  # Cloning repository
  if [ ! -d ${__repo_full_tmp_dir} ]; then
    git clone ${__repo_url} ${__repo_full_tmp_dir} || __error_flag=1
  else
    git -C ${__repo_full_tmp_dir} pull --all || __error_flag=1
  fi

  [ ${__error_flag} -eq 1 ] && __error_list+=(${__repo_url}) && continue

  # Setting fileMode to false, so file permissions won't change file status
  git -C ${__repo_full_tmp_dir} config core.fileMode false

  {
    # Checking out every branch, copying Jenkinsfile and .gitattributes and committing
    __remote="origin"
    for __branch in $(git branch -r | grep ${__remote} | grep -v HEAD | awk '{gsub(/^[^\/]+\//,"",$1); print $1}'); do
        echo "-> Checking out branch '${__branch}'"
        git -C ${__repo_full_tmp_dir} checkout --force ${__branch}
        git -C ${__repo_full_tmp_dir} pull

        cp -fv ${__jenkinsfile_path} ${__repo_full_tmp_dir}/
        cp -fv ${__gitattributes_path} ${__repo_full_tmp_dir}/

        git -C ${__repo_full_tmp_dir} add Jenkinsfile .gitattributes
        git -C ${__repo_full_tmp_dir} commit -m "Jenkinsfile and .gitattributes updated"
    done
  } || __error_list+=(${__repo_url})

  echo
done

# Removing repos with error
for i in "${__error_list[@]}"; do
  __repo_list=(${__repo_list[@]//*$i*})
done

# If everything is good, push all branches from all repositories
for __repo_url in "${__repo_list[@]}"; do
  __repo_name="${__repo_url##*/}"
  __repo_name="${__repo_name%.git}"
  __repo_full_tmp_dir="${__repos_tmp_dir}/${__repo_name}"

  echo
  echo "--------------------------------------------------------------------------------"
  echo "Pushing ${__repo_name}"
  echo "--------------------------------------------------------------------------------"

  # Cloning repository
  if [ -d ${__repo_full_tmp_dir} ]; then
     git -C ${__repo_full_tmp_dir} push --all || __error_list+=(${__repo_url})
    echo "Push OK!!!!"
  else
    __error_list+=(${__repo_url})
  fi

  echo
done

_check_errors
